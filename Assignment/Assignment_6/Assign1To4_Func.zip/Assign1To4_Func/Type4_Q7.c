#include <stdio.h>

double calculateSalary(double bs) {
	double da, ta, hra, ts;
	if (bs <= 5000) {
		da  = bs * 0.10;
		ta  = bs * 0.20;
		hra = bs * 0.25;
	} else {
		da  = bs * 0.15;
		ta  = bs * 0.25;
		hra = bs * 0.30;
	}
	ts = bs + da + ta + hra;
	return ts;
}
int main() {
	double bs, result;
	printf("Enter base salary: ");
	scanf("%lf", &bs);

	result = calculateSalary(bs);
	printf("Total salary : %.2f\n", result);
	return 0;
}