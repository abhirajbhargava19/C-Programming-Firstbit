#include<stdio.h>

int checkUpperLowercase(int ch) {
	if (ch >= 'A' && ch <= 'Z')
		return 0;
	else
		return 1;
}
int main() {
	char s ;
	printf("Enter a Character: ");
	scanf("%c",&s);

	int res = checkUpperLowercase(s);
	if(res == 0)
		printf("%c is Uppercase",s);
	else
		printf("%c is lowercase",s);
	return 0;
}