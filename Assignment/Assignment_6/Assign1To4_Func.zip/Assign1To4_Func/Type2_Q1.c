#include<stdio.h>

int checkEvenOdd( ) {
	int num;
	printf("Enter a Number: ");
	scanf("%d",&num);
	if(num % 2 == 0)
		return 0;
	else
		return 1;
}
int main() {
	int res = checkEvenOdd();
	if(res == 0) {
		printf("Number is Even\n");
	} else {
		printf("Number is Odd\n");
	}
	return 0;
}