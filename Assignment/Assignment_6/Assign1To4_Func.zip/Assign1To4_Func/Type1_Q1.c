#include<stdio.h>

void printNumbers() {
	int n;
	printf("Enter a Number: ");
	scanf("%d",&n);

	for(int i=0; i <= n; i++) {
		printf("%d ",i);
	}
}
int main() {
	printNumbers();
	return 0;
}