#include <stdio.h>

int checkUpperLowercase() {
	char ch ;
	printf("Enter a Character: ");
	scanf("%c",&ch);

	if (ch >= 'A' && ch <= 'Z')
		return 0;
	else
		return 1;
}
int main() {
	int res = checkUpperLowercase();
	if(res == 0)
		printf("%c character is Uppercase");
	else
		printf("%c charcter is lowercase");
	return 0;
}