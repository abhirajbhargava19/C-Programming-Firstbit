#include<stdio.h>

int checkEvenOdd(int num ) {
	if(num % 2 == 0)
		return 0;
	else
		return 1;
}
int main() {
	int n;
	printf("Enter a Number: ");
	scanf("%d",&n);

	int res = checkEvenOdd(n);
	if(res == 0) {
		printf("%d is Even Number",n);
	} else {
		printf("%d is Odd Number",n);
	}
	return 0;
}