#include <stdio.h>

void calculator(int num1, int num2, char op) {
	if (op == '+')
		printf("Result is %d", num1 + num2);
	else if (op == '-')
		printf("Result is %d", num1 - num2);
	else if (op == '*')
		printf("Result is %d", num1 * num2);
	else if (op == '/')
		printf("Result is %d", num1 / num2);
	else if (op == '%')
		printf("Result is %d", num1 % num2);
	else
		printf("Invalid Operator");
}
int main() {
	int num1, num2;
	char op;

	printf("Enter first Number: ");
	scanf("%d", &num1);
	printf("Enter Operator: ");
	scanf(" %c", &op);
	printf("Enter second Number: ");
	scanf("%d", &num2);

	calculator(num1, num2, op);
	return 0;
}