#include<stdio.h>

void printPerfect() {
	int n, i, j, sum;

	printf("Enter a Number: ");
	scanf("%d", &n);
	for(i = 2; i <= n; i++) {
		sum = 0;
		for(j = 1; j <= i/2; j++) {
			if(i % j == 0)
				sum = sum + j;
		}
		if(sum == i)
			printf("%d ", i);
	}
}
int main() {
	printPerfect();
	return 0;
}