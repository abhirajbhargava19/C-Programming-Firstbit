#include <stdio.h>

void checkPalindrome() {
	int num, n, sum = 0;

	printf("Enter Number: ");
	scanf("%d",&n);
	num = n;

	for(int i=0; i<3; i++) {
		int digit = num % 10;
		sum = sum + digit*digit*digit;
		num = num / 10;
	}
	if (sum == n)
		printf("%d is Armstrong",n);
	else
		printf("%d is Not Armstrong",n);
}
int main() {
	checkPalindrome();
	return 0;
}

