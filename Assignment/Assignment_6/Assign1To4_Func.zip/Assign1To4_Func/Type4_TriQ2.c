#include<stdio.h>

int checkTriangle(int side1, int side2, int side3) {
	if (side1 == side2 && side2 == side3)
		return 0;
	else if (side1 == side2 || side2 == side3 || side1 == side3)
		return 1;
	else
		return 2;
}
int main() {
	int side1, side2, side3;
	printf("Enter three sides: ");
	scanf("%d %d %d", &side1, &side2, &side3);

	int result = checkTriangle(side1, side2, side3);
	if (result == 0)
		printf("Triangle is equilateral");
	else if (result == 1)
		printf("Triangle is isosceles");
	else
		printf("Triangle is scalene");

	return 0;
}