#include<stdio.h>

void checkPalindrome(int n) {
	int num, i, digits, digit, rev = 0, temp;

	digits = 0;
	temp = n;
	for(i = 0; temp > 0; i++) {
		digits++;
		temp = temp / 10;
	}
	num = n;
	for(i = 0; i < digits; i++) {
		digit = num % 10;
		rev = rev * 10 + digit;
		num = num / 10;
	}
	if(rev == n)
		printf("%d is Palindrome", n);
	else
		printf("%d is Not Palindrome", n);
}

int main() {
	int num;
	printf("Enter a Number: ");
	scanf("%d", &num);
	checkPalindrome(num);
	return 0;
}