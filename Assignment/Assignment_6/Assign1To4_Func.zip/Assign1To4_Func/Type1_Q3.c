#include<stdio.h>

void SumNumbers() {
	int start, end, sum = 0;

	printf("Enter Start: ");
	scanf("%d",&start);
	printf("Enter End: ");
	scanf("%d",&end);
	for(int i=start; i <= end; i++)
		sum =sum+i;
	printf("%d",sum);
}

int main() {
	SumNumbers();
	return 0;
}
