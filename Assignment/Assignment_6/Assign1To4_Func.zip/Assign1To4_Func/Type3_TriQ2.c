#include<stdio.h>

void checkTriangle(int side1, int side2, int side3) {

	if (side1 == side2 && side2 == side3)
		printf("Triangle is equilateral");
	else if (side1 == side2 || side2 == side3 || side1 == side3)
		printf("Triangle is isosceles");
	else
		printf("Triangle is scalene");
}
int main() {
	int side1, side2, side3;
	printf("Enter three sides: ");
	scanf("%d %d %d", &side1, &side2, &side3);
	checkTriangle(side1, side2, side3);

	return 0;
}