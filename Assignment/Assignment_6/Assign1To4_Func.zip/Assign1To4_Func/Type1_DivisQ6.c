#include <stdio.h>

void checkDivisible() {
	int num;
	printf("Enter Number: ");
	scanf("%d",&num);

	if (num % 3 == 0 && num % 5 == 0)
		printf("%d Divisible by both\n",num);
	else if (num % 3 == 0)
		printf("%d Divisible by 3 but not by 5\n",num);
	else if (num % 5 == 0)
		printf("%d Divisible by 5 but not by 3\n",num);
	else
		printf("%d Divisible by None\n",num);
}
int main() {
	checkDivisible();
	return 0;
}
