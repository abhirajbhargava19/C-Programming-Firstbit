#include <stdio.h>
int VowelConsonant(char c) {
	if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
	        c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U')
		return 0;
	else
		return 1;
}
int main() {
	char ch;
	printf("Enter a character: ");
	scanf("%c",&ch);
	int res = VowelConsonant(ch);
	if(res == 0)
		printf("%c is Vowel",ch);
	else
		printf("%c is Consonant",ch);
	return 0;
}