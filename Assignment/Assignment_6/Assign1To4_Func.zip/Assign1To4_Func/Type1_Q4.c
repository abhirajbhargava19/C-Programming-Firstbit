#include<stdio.h>

void CheckPrime() {
	int num, status =0;
	printf("Enter Number: ");
	scanf("%d",&num);

	for(int i = 2; i <= num/2; i++) {
		if(num % i == 0)
			status = 1;
		break;
	}
	if(status == 0)
		printf("prime\n");
	else
		printf("not prime\n");
}
int main() {
	CheckPrime();
	return 0;
}
