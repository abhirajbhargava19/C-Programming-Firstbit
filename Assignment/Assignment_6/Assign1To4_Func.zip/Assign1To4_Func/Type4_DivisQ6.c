#include <stdio.h>

int checkDivisible(int num) {

	if (num % 3 == 0 && num % 5 == 0)
		return 0;
	else if (num % 3 == 0)
		return 1;
	else if (num % 5 == 0)
		return 2;
	else
		return 3;
}
int main() {
	int n;
	printf("Enter Number: ");
	scanf("%d",&n);
	int res = checkDivisible(n);
	if (res == 0)
		printf("Divisble by both\n");
	else if (res == 1)
		printf("Divisible by 3 but not by 5\n");
	else if ( res == 2)
		printf("Divisible by 5 but not by 3\n");
	else
		printf("Divisible by None\n");

	return 0;
}
