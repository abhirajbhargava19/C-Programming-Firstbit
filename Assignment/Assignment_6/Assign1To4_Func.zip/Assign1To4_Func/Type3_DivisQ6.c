#include <stdio.h>

void checkDivisible(int num) {

	if (num % 3 == 0 && num % 5 == 0)
		printf("%d Divisble by both\n",num);
	else if (num % 3 == 0)
		printf("%d Divisible by 3 but not by 5\n",num);
	else if (num % 5 == 0)
		printf("%d Divisible by 5 but not by 3\n",num);
	else
		printf("%d Divisible by None\n",num);
}
int main() {
	int n;
	printf("Enter Number: ");
	scanf("%d",&n);
	checkDivisible(n);
	return 0;
}
