#include <stdio.h>

int VowelConsonant() {
	char ch;
	printf("Enter a Character: ");
	scanf("%c",&ch);
	if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ||
	        ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U')
		return 0;
	else
		return 1;
}
int main() {
	int res = VowelConsonant();
	if(res == 0)
		printf("Character is Vowel\n");
	else
		printf("Character is Consonant\n");
	return 0;
}


