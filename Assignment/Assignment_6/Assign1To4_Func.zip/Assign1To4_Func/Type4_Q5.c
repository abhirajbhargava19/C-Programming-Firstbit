#include<stdio.h>

int checkVoteAge(int age) {
	if(age >= 18 )
		return 0;
	else
		return 1;
}
int main() {
	int a ;
	printf("Enter a Number: ");
	scanf("%d",&a);
	int res = checkVoteAge(a);
	if(res == 0)
		printf("%d age is eligible for vote\n",a);
	else
		printf("%d  age is not  eligible for vote\n",a);
	return 0;
}