#include <stdio.h>

int checkAgeGroup(int age) {

	if (age < 12)
		return 0;
	else if (age <= 19)
		return 1;
	else if (age <= 59)
		return 2;
	else
		return 3;
}
int main() {
	int a;
	printf("Enter Number: ") ;
	scanf("%d",&a);
	int res = checkAgeGroup(a);

	if (res == 0)
		printf("Age is Child");
	else if (res == 1)
		printf("Age is Teenager");
	else if( res == 2)
		printf("Age is Adult");
	else 
		printf("Age is Senior");

	return 0;
}