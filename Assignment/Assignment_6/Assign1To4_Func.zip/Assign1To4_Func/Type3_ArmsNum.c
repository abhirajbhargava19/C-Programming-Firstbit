#include<stdio.h>

void printArmstrong(int n) {
	int i, num, digit, sum, digits, temp, power, j;

	for(i = 1; i <= n; i++) {
		digits = 0;
		temp = i;
		while(temp > 0) {
			digits++;
			temp = temp / 10;
		}
		num = i;
		sum = 0;
		while(num > 0) {
			digit = num % 10;
			power = 1;
			for(j = 0; j < digits; j++)
				power = power * digit;
			sum = sum + power;
			num = num / 10;
		}
		if(sum == i)
			printf("%d ", i);
	}
}
int main() {
	int n;
	printf("Enter a Number: ");
	scanf("%d", &n);
	printArmstrong(n);
	return 0;
}