#include <stdio.h>

int calculator() {
	int num1, num2, result;
	char op;
	printf("Enter first Number: ");
	scanf("%d", &num1);
	printf("Enter Operator: ");
	scanf(" %c", &op);
	printf("Enter second Number: ");
	scanf("%d", &num2);

	if (op == '+')
		result = num1 + num2;
	else if (op == '-')
		result = num1 - num2;
	else if (op == '*')
		result = num1 * num2;
	else if (op == '/')
		result = num1 / num2;
	else if (op == '%')
		result = num1 % num2;
	else {
		printf("Invalid Operator");
		return 0;
	}
	return result;
}
int main() {
	int res;
	res = calculator();
	printf("Result is %d", res);
	return 0;
}