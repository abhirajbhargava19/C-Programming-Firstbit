#include<stdio.h>

void checkPalindrome() {
	int n, num, i, digits, digit, rev = 0, temp;

	printf("Enter a Number: ");
	scanf("%d", &n);

	digits = 0;
	temp = n;
	for(i = 0; temp > 0; i++) {
		digits++;
		temp = temp / 10;
	}
	for(i = 0; i < digits; i++) {
		digit = num % 10;
		rev = rev * 10 + digit;
		num = num / 10;
	}
	if(rev == n)
		printf("%d is Palindrome", n);
	else
		printf("%d is Not Palindrome", n);
}
int main() {
	checkPalindrome();
	return 0;
}