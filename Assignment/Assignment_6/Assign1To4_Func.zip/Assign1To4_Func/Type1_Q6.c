#include<stdio.h>

void checkPerfect() {
	int n, i, sum = 0;

	printf("Enter a Number: ");
	scanf("%d", &n);

	for(i = 1; i <= n/2; i++) {
		if(n % i == 0)
			sum = sum + i;
	}
	if(sum == n)
		printf("%d is Perfect", n);
	else
		printf("%d is Not Perfect", n);
}
int main() {
	checkPerfect();
	return 0;
}