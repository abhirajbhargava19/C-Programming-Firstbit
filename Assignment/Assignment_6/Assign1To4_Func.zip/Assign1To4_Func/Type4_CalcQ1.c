#include <stdio.h>

int calculator(int num1, int num2, char op) {
	int result;

	if (op == '+')
		result = num1 + num2;
	else if (op == '-')
		result = num1 - num2;
	else if (op == '*')
		result = num1 * num2;
	else if (op == '/')
		result = num1 / num2;
	else if (op == '%')
		result = num1 % num2;
	else {
		printf("Invalid Operator");
		return 0;
	}
	return result;
}
int main() {
	int num1, num2, res;
	char op;

	printf("Enter first Number: ");
	scanf("%d", &num1);
	printf("Enter Operator: ");
	scanf(" %c", &op);
	printf("Enter second Number: ");
	scanf("%d", &num2);

	res = calculator(num1, num2, op);
	printf("Result is %d", res);
	return 0;
}