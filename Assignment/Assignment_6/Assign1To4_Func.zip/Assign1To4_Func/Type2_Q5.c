#include<stdio.h>

int checkVoteAge() {
	int age ;
	printf("Enter a Number: ");
	scanf("%d",&age);
	if(age >= 18 )
		return 0;
	else
		return 1;
}
int main() {
	int res = checkVoteAge();
	if(res == 0)
		printf("age is eligible for vote\n");
	else
		printf("age is not eligible for vote\n");
	return 0;
}
