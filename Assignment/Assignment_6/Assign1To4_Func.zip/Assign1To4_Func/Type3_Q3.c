#include<stdio.h>

void SumNumbers(int start,int end) {
	int sum = 0;

	for(int i=start; i <= end; i++)
		sum =sum+i;
	printf("%d",sum);
}

int main() {
	int s, e;
	printf("Enter Start: ");
	scanf("%d",&s);

	printf("Enter End: ");
	scanf("%d",&e);
	SumNumbers(s,e);
	return 0;
}
