#include<stdio.h>

void  TableNumbers() {
	int n;
	printf("Enter Number: ");
	scanf("%d",&n);

	for(int i=1; i <= n; i++ )
		printf("%d ",n*i);
}
int main() {
	TableNumbers();
	return 0;
}