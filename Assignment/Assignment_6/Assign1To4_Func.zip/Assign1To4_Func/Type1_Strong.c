#include<stdio.h>

void printStrong() {
    int n, i, num, j, digit, sum, fact;

    printf("Enter a Number: ");
    scanf("%d", &n);
    for(i = 1; i <= n; i++) {
        num = i;
        sum = 0;
        while(num > 0) {
            digit = num % 10;
            fact = 1;
            for(j = 1; j <= digit; j++)
                fact = fact * j;
            sum = sum + fact;
            num = num / 10;
        }
        if(sum == i)
            printf("%d ", i);
    }
}
int main() {
    printStrong();
    return 0;
}   