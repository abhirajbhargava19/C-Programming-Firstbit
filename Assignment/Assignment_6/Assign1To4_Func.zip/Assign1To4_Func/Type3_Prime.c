#include<stdio.h>

void printPrimes(int n) {
	int i, j, flag;
	for(i = 2; i <= n; i++) {
		flag = 0;
		for(j = 2; j <= i/2; j++) {
			if(i % j == 0) {
				flag = 1;
				break;
			}
		}
		if(flag == 0)
			printf("%d ", i);
	}
}
int main() {
	int n;
	printf("Enter a Number: ");
	scanf("%d", &n);
	printPrimes(n);
	return 0;
}