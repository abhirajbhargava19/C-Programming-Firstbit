#include <stdio.h>

void checkAgeGroup(int age) {

	if (age < 12)
		printf("%d Age is Child",age);
	else if (age <= 19)
		printf("%d Age is Teenager",age);
	else if (age <= 59)
		printf("%d Age is Adult",age);
	else
		printf("%d Age is Senior",age);
}
int main() {
	int a;
	printf("Enter Number: ") ;
	scanf("%d",&a);
	checkAgeGroup(a);

	return 0;
}