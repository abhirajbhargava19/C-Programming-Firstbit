#include<stdio.h>

void  TableNumbers(int n) {
	
	for(int i=1; i <= n; i++ )
		printf("%d ",n*i);
}

int main() {
	int num;
	printf("Enter Number: ");
	scanf("%d",&num);
	
	TableNumbers(num);
	return 0;
}