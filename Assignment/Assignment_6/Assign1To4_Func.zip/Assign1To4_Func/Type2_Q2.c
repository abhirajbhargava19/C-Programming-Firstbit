#include<stdio.h>

int checkPalindrome( ) {
	int num;
	printf("Enter a Number: ",num);
	scanf("%d",&num);
	if(num / 100 == num % 10)
		return 0;
	else
		return 1;
}
int main() {
	int n;
	int res = checkPalindrome();
	if(res == 0)
		printf("Number is palindrome ");
	else
		printf("Number is not palindrome ");
	return 0;
}