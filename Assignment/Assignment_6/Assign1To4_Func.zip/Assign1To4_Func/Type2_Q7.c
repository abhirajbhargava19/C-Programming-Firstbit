#include <stdio.h>
double checkSalary() {
	double bs, da, ta, hra, ts;
	printf("Enter base salary: ");
	scanf("%lf", &bs);

	if (bs <= 5000) {
		da  = bs * 0.10;
		ta  = bs * 0.20;
		hra = bs * 0.25;
	} else {
		da  = bs * 0.15;
		ta  = bs * 0.25;
		hra = bs * 0.30;
	}
	ts = bs + da + ta + hra;
	return ts;
}
int main() {
	double res;
	res = checkSalary();
	printf("Total salary : %.2f\n", res);
	return 0;
}