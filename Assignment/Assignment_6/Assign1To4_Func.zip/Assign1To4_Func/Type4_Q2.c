#include<stdio.h>
int checkPalindrome(int num) {
	if(num / 100 == num % 10)
		return 0;
	else
		return 1;
}

int main() {
	int n;
	printf("Enter a Number: ",n);
	scanf("%d",&n);
	int res = checkPalindrome(n);
	if(res == 0)
		printf("%d is Palindrome Number",n);
	else
		printf("%d is not Palindrome Number",n);
	return 0;
}