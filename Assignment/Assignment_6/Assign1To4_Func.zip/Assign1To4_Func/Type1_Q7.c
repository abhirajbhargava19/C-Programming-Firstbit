#include<stdio.h>

void factorial() {
    int n, i, fact = 1;

    printf("Enter a Number: ");
    scanf("%d", &n);

    for(i = 1; i <= n; i++)
        fact = fact * i;

    printf("%d", fact);
}
int main() {
    factorial();
    return 0;
}   